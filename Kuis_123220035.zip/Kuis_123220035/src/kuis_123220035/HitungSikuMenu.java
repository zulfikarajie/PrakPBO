/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kuis_123220035;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.*;
import java.awt.event.ActionListener;

public class HitungSikuMenu {
    private JFrame frame;
    private JButton HitungBT, ExitBT;
    private JTextField NilaiA, NilaiB;
    private JLabel hasilLabel;

    public HitungSikuMenu() {
        frame = new JFrame("MENU HITUNG SIKU");
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout(10, 10));

        NilaiA = new JTextField(15);
        NilaiB = new JTextField(15);

        HitungBT = new JButton("Hitung");
        ExitBT = new JButton("Kembali");

        HitungBT.addActionListener(this::HitungAction);
        ExitBT.addActionListener(this::ExitAction);

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(3, 2, 5, 5));
        inputPanel.add(new JLabel("Nilai A"));
        inputPanel.add(NilaiA);
        inputPanel.add(new JLabel("Nilai B"));
        inputPanel.add(NilaiB);
        inputPanel.add(new JLabel("Hasil"));
        hasilLabel = new JLabel();
        inputPanel.add(hasilLabel);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 5));
        buttonPanel.add(HitungBT);
        buttonPanel.add(ExitBT);

        frame.add(inputPanel, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        frame.setVisible(true);
    }

    private void ExitAction(ActionEvent event) {
        frame.setVisible(false);
    }

    private void HitungAction(ActionEvent event) {
        try {
            float nilaiA = Float.parseFloat(NilaiA.getText());
            float nilaiB = Float.parseFloat(NilaiB.getText());

            double result = Math.sqrt(nilaiA * nilaiA + nilaiB * nilaiB);
            hasilLabel.setText(String.valueOf(result));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Input Error, Masukkan Angka!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}