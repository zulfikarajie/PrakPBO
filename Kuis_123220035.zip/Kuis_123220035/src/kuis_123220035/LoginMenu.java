/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kuis_123220035;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginMenu extends JFrame implements ActionListener {
    JButton log, can;
    JTextField tusm;
    JPasswordField tpsw;
    CardLayout cardLayout;
    JPanel cardPanel;
    JLabel lblLogin;

    public LoginMenu() {
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);

        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(new GridLayout(5, 2, 5, 5));

        JLabel usm = new JLabel("Username : ");
        JLabel psw = new JLabel("Password : ");

        tusm = new JTextField(20);
        tpsw = new JPasswordField(20);

        log = new JButton("Login");
        can = new JButton("Cancel");
        log.addActionListener(this);
        can.addActionListener(this);

        loginPanel.add(usm);
        loginPanel.add(tusm);
        loginPanel.add(psw);
        loginPanel.add(tpsw);
        loginPanel.add(log);
        loginPanel.add(can);

        lblLogin = new JLabel("Status : ");
        lblLogin.setHorizontalAlignment(SwingConstants.LEFT);
        loginPanel.add(lblLogin);

        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT)); // Gunakan FlowLayout untuk label status
        JLabel baru = new JLabel("Berhasil Login");
        statusPanel.add(baru);

        cardPanel.add(loginPanel, "login");
        cardPanel.add(statusPanel, "baru");

        add(cardPanel);

        setVisible(true);
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == log) {
            String username = tusm.getText();
            String password = new String(tpsw.getPassword());
            if ("tukang_035".equals(username) && "tukang_035".equals(password)) {
                lblLogin.setText("Status: Berhasil");
                cardLayout.show(cardPanel, "baru");
            } else {
                lblLogin.setText("Status: Salah");
            }
        } else if (e.getSource() == can) {
            lblLogin.setText("Status: Login Dibatalkan");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LoginMenu();
        });
    }
}
