/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package kuis_123220035;

import javax.swing.*;
import java.awt.event.*;

public class ScreenMenu extends JFrame implements ActionListener {

    private JButton HitungSikuBT;
    private JButton LoginBT;
    private JButton ExitBT;
    
    public ScreenMenu(){
        setTitle("PT. Ukang | 123220035");
        setSize(400,100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        HitungSikuBT = new JButton("Hitung Siku");
        LoginBT = new JButton("Login");
        ExitBT = new JButton("Exit");
        
        HitungSikuBT.addActionListener(this);
        LoginBT.addActionListener(this);
        ExitBT.addActionListener(this);
        
        JPanel panel = new JPanel();
        panel.add(HitungSikuBT);
        panel.add(LoginBT);
        panel.add(ExitBT);
        add(panel);
        
        setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e){
        if (e.getSource() == HitungSikuBT){
            new HitungSikuMenu();
        } else if (e.getSource() == LoginBT){
            new LoginMenu();
        } else if (e.getSource() == ExitBT){
            System.exit(0);
        }
    }
    
    public static void main(String[] args) {
        new ScreenMenu();
    }
}
