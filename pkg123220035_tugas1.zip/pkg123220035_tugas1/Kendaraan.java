/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg123220035_tugas1;

/**
 *
 * @author apang
 */
public class Kendaraan {
    protected String jenisKendaraan;

    public Kendaraan(String jenisKendaraan) {
        this.jenisKendaraan = jenisKendaraan;
    }

    public String getInfoKendaraan() {
        return "Jenis Kendaraan: " + jenisKendaraan;
    }
    
    public String getJenisKendaraan() {
        return jenisKendaraan;
    }
}

