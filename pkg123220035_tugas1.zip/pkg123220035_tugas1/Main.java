/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg123220035_tugas1;

/**
 *
 * @author apang
 */
public class Main {
public static void main(String[] args) {
        Kendaraan kendaraan1 = new Mobil("Mobil", "Toyota");
        Kendaraan kendaraan2 = new Bus("Bus", "PO.Haryanto");

        showInfo(kendaraan1);
        showInfo(kendaraan2);
    }

    // Polymorphism
    public static void showInfo(Kendaraan kendaraan) {
        System.out.println(kendaraan.getInfoKendaraan() + ", Jenis: " + kendaraan.getJenisKendaraan());
    }

}
