/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg123220035_tugas1;

/**
 *
 * @author apang
 */
public class Mobil extends Kendaraan {
    private String merk;

    public Mobil(String jenisKendaraan, String merk) {
        super(jenisKendaraan);
        this.merk = merk;
    }

    @Override
    public String getInfoKendaraan() {
        return super.getInfoKendaraan() + ", Merk: " + merk;
    }

    // Encapsulation
    public String getMerk() {
        return merk;
    }

    public void setMerk(String merk) {
        this.merk = merk;
    }
    
    @Override
    public String getJenisKendaraan() {
        return "Pribadi";
    }
}
