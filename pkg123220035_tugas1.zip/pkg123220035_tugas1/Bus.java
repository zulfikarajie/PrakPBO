/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg123220035_tugas1;

/**
 *
 * @author apang
 */
public class Bus extends Kendaraan {
    private String pemilik;

    public Bus(String jenisKendaraan, String pemilik) {
        super(jenisKendaraan);
        this.pemilik = pemilik;
    }

    @Override
    public String getInfoKendaraan() {
        return super.getInfoKendaraan() + ", Pemilik: " + pemilik;
    }
    
    @Override
    public String getJenisKendaraan() {
        return "Umum";
    }
    
    // Encapsulation
    public String getPemilik() {
        return pemilik;
    }
}